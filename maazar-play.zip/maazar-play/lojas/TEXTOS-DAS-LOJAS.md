# Textos e respostas para as lojas

Copie e cole nos formulários de cada loja. Troque o que estiver entre `< >`.
Site do app: `https://contatocapclean-hue.github.io/maazar-play`

---

## Nome do app
**Maazar Play**

## Descrição curta (até 80 caracteres)
Reprodutor para as suas listas M3U e de servidor, no celular, TV e computador.

## Descrição completa

O Maazar Play é um reprodutor de vídeo para as listas que você já possui.

Adicione a sua lista, seja o endereço de um servidor com usuário e senha ou o endereço de uma lista M3U, e assista com uma tela feita para TV e controle remoto.

RECURSOS
• Tela inicial com destaques, filmes, séries e canais organizados em fileiras
• Todas as categorias à mão, busca e Minha Lista (favoritos)
• Continuar assistindo de onde parou e próximo episódio automático
• Temporadas e episódios com sinopse e capas (quando a lista fornece)
• Feito para controle remoto: setas, OK, Voltar, CH+/CH− e números
• Funciona em celulares e tablets Android, Android TV, Google TV e Fire TV
• Ajuste de margem para TVs que cortam as bordas da imagem
• Sem cadastro: seus dados ficam só no seu aparelho

IMPORTANTE
O Maazar Play NÃO vende, não fornece e não indica canais, filmes, séries, listas ou assinaturas. O app não contém nenhum conteúdo. Para usar, você precisa ter uma lista própria, de uma fonte que tenha o direito de distribuí-la. As imagens desta página são ilustrativas.

Política de privacidade: https://contatocapclean-hue.github.io/maazar-play/privacidade.html
Termos de uso: https://contatocapclean-hue.github.io/maazar-play/termos.html

---

## Categoria
- Google Play: **Players e editores de vídeo**
- Amazon: **Vídeo**
- LG e Samsung: **Vídeo**

## Classificação etária (questionário)
- Violência, sexo, linguagem, drogas, apostas: **não** (o app não tem conteúdo próprio).
- O app permite acessar conteúdo escolhido pelo usuário: **sim**. O usuário adiciona a própria lista.
- Público-alvo: **18 anos ou mais**.

## Anúncios
**Não** contém anúncios.

## Acesso ao app (instruções para o revisor)
> O app não tem login. Para testar a reprodução, toque em "Adicionar lista" › aba "Lista M3U" e cole o endereço abaixo, que é uma lista pública de canais abertos e gratuitos (projeto iptv-org):
> `https://iptv-org.github.io/iptv/languages/por.m3u`
> Depois, abra "Canais de TV" e escolha um canal.

## Segurança dos dados (Google Play: Data safety)
- **O app coleta ou compartilha dados do usuário?** **Não.** Os dados digitados (endereço da lista, usuário e senha) ficam só no aparelho e não são enviados ao desenvolvedor.
- **Criptografia em trânsito:** não se aplica, porque nada é enviado ao desenvolvedor.
- **Exclusão de dados:** não se aplica. Os dados ficam no aparelho e são apagados ao limpar os dados do app ou desinstalar.

## Links obrigatórios
- Política de privacidade: `https://contatocapclean-hue.github.io/maazar-play/privacidade.html`
- Site: `https://contatocapclean-hue.github.io/maazar-play`
- E-mail de contato: `maazarserv@gmail.com`

## Imagens (pasta `lojas/`)
| Arquivo | Uso |
|---|---|
| `icone-512.png` | Ícone da loja (Google Play, 512×512) |
| `destaque-google-play-1024x500.png` | Imagem de destaque da Google Play |
| `banner-tv-1280x720.png` | Banner de Android TV (Google Play) e Fire TV |
| `capturas/celular-*.png` | Capturas de celular (1080×1920) |
| `capturas/tv-*.png` | Capturas de TV (1920×1080): Android TV, Fire TV, LG, Samsung |

---

## Textos em inglês (idioma English (US) das lojas)
Use estes no idioma **English (US)**. Os textos em português vão só no idioma **Português (Brasil)**.

**Short description**
Player for your own M3U and server playlists on phone, TV and computer.

**Full description**
Maazar Play is a video player for the playlists you already have.

Add your playlist, either a server address with username and password or an M3U playlist URL, and watch on an interface designed for TV and remote control.

FEATURES
• Home screen with highlights, movies, series and channels organized in rows
• All categories at hand, search and My List (favorites)
• Continue watching where you left off and automatic next episode
• Seasons and episodes with synopsis and artwork (when provided by the playlist)
• Built for the remote: arrows, OK, Back, CH+/CH− and number keys
• Works on Android phones and tablets, Android TV, Google TV and Fire TV
• Screen margin adjustment for TVs that crop the picture edges
• No sign-up: your data stays only on your device

IMPORTANT
Maazar Play does NOT sell, provide or recommend channels, movies, series, playlists or subscriptions. The app contains no content. To use it, you need your own playlist from a source that has the right to distribute it. Images on this page are illustrative.

Privacy policy: https://contatocapclean-hue.github.io/maazar-play/privacidade.html
Terms of use: https://contatocapclean-hue.github.io/maazar-play/termos.html

**Feature bullets (Amazon)**
• Plays your own M3U and Xtream server playlists
• TV-friendly interface built for the remote control
• Movies, series and live channels with search and favorites
• Continue watching and automatic next episode
• No ads and no sign-up; data stays on your device
