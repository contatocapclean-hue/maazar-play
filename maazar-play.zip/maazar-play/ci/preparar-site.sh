#!/usr/bin/env bash
# Coloca o e-mail de contato (variável CONTATO_EMAIL do repositório) nas páginas do site.
set -e
cd "$(dirname "$0")/../site"
CONTATO_EMAIL="${CONTATO_EMAIL:-maazarserv@gmail.com}"
if [ -n "$CONTATO_EMAIL" ]; then
  LINK="<a href=\"mailto:${CONTATO_EMAIL}\">${CONTATO_EMAIL}</a>"
else
  LINK="pelo e-mail informado na página do app na loja"
fi
for f in *.html; do
  node -e "const fs=require('fs');const f=process.argv[1];fs.writeFileSync(f,fs.readFileSync(f,'utf8').split('__CONTATO__').join(process.argv[2]))" "$f" "$LINK"
done
echo "Site pronto (contato: ${CONTATO_EMAIL:-não definido})"
