package com.maazar.play;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int FILE_REQUEST = 41;
    /* O app é servido de um endereço interno (appassets), em vez de arquivos locais. */
    private static final String APP_HOST = "appassets.androidplatform.net";
    /* A interface abre por http interno: as listas e os vídeos dos servidores quase sempre usam http,
       e uma página https faria o Android bloquear ou converter esses endereços (conteúdo misto). */
    private static final String HOME = "http://" + APP_HOST + "/assets/index.html";

    private WebView web;
    private FrameLayout root;
    private WebViewAssetLoader assets;
    private ValueCallback<Uri[]> fileCallback;
    private Intent pendingIntent;
    private boolean pageReady = false;
    private boolean immersive = false;
    private Object backCallback;
    private CastHelper cast;
    private float navInsetCss = 0;   // altura da barra de navegação do Android, em px da página

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        assets = new WebViewAssetLoader.Builder()
                .setDomain(APP_HOST)
                .setHttpAllowed(true)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#020A33"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#020A33"));
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        setupInsets();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Sem acesso a arquivos locais: tudo vem do endereço interno seguro.
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        // Mantém o tamanho do texto igual em todo aparelho.
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        // Transmitir para a TV: só no celular/tablet (na TV não faz sentido)
        if (!isTelevision()) {
            try { cast = new CastHelper(this, web); } catch (Throwable t) { cast = null; }
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return assets.shouldInterceptRequest(u);
                return proxy(request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    toast("Nenhum app consegue abrir este link.");
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                pushInsets();
                if (pendingIntent != null) {
                    Intent i = pendingIntent;
                    pendingIntent = null;
                    importFromIntent(i);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Escolher lista M3U"), FILE_REQUEST);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    toast("Este aparelho não tem um gerenciador de arquivos.");
                    return false;
                }
                return true;
            }
        });

        setupBack();

        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        pendingIntent = getIntent();
        web.loadUrl(HOME);
    }

    /* ------------------------------------------------------------------
       Conexões com os servidores das listas.
       O próprio app faz o pedido e devolve a resposta à página, liberando o
       acesso (CORS). Listas HLS redirecionadas têm os endereços relativos
       corrigidos para continuar funcionando.
       ------------------------------------------------------------------ */
    private WebResourceResponse proxy(WebResourceRequest req) {
        try {
            if (!"GET".equalsIgnoreCase(req.getMethod())) return null;
            Uri u = req.getUrl();
            String scheme = u.getScheme();
            if (!"http".equals(scheme) && !"https".equals(scheme)) return null;
            Map<String, String> rh = req.getRequestHeaders();
            String accept = header(rh, "Accept");
            if (header(rh, "Range") != null) return null;                       // vídeo direto (filmes)
            if (accept != null && accept.startsWith("image/")) return null;     // capas e logos
            String host = u.getHost() == null ? "" : u.getHost();
            if (host.endsWith(".supabase.co") || host.startsWith("fonts.")) return null;

            String current = u.toString();
            HttpURLConnection c = null;
            int status = 0;
            for (int hop = 0; hop < 6; hop++) {
                c = (HttpURLConnection) new URL(current).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                for (Map.Entry<String, String> h : rh.entrySet()) {
                    String k = h.getKey();
                    if (k == null) continue;
                    String kl = k.toLowerCase(Locale.ROOT);
                    if (kl.equals("origin") || kl.equals("referer") || kl.startsWith("sec-") || kl.equals("x-requested-with")) continue;
                    c.setRequestProperty(k, h.getValue());
                }
                status = c.getResponseCode();
                if (status >= 300 && status < 400 && c.getHeaderField("Location") != null) {
                    current = new URL(new URL(current), c.getHeaderField("Location")).toString();
                    c.disconnect();
                    continue;
                }
                break;
            }
            if (c == null) return null;

            String ctype = c.getContentType();
            String mime = "application/octet-stream", enc = null;
            if (ctype != null) {
                String[] parts = ctype.split(";");
                mime = parts[0].trim();
                for (String p : parts) {
                    String pt = p.trim().toLowerCase(Locale.ROOT);
                    if (pt.startsWith("charset=")) enc = p.trim().substring(8);
                }
            }
            InputStream body = status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (body == null) body = new ByteArrayInputStream(new byte[0]);

            boolean redirected = !current.equals(u.toString());
            boolean isPlaylist = mime.toLowerCase(Locale.ROOT).contains("mpegurl") || current.toLowerCase(Locale.ROOT).contains(".m3u8");
            if (redirected && isPlaylist && status < 400) {
                body = new ByteArrayInputStream(absolutize(readAll(body), current).getBytes("UTF-8"));
                enc = "UTF-8";
            }

            Map<String, String> out = new HashMap<>();
            for (Map.Entry<String, List<String>> h : c.getHeaderFields().entrySet()) {
                String k = h.getKey();
                if (k == null || h.getValue() == null || h.getValue().isEmpty()) continue;
                String kl = k.toLowerCase(Locale.ROOT);
                if (kl.startsWith("access-control-") || kl.equals("content-length") || kl.equals("content-encoding") || kl.equals("transfer-encoding") || kl.equals("set-cookie")) continue;
                out.put(k, h.getValue().get(0));
            }
            out.put("Access-Control-Allow-Origin", "*");
            out.put("Access-Control-Expose-Headers", "*");
            if (status < 100 || (status >= 300 && status < 400)) status = 200;
            String reason = c.getResponseMessage();
            if (reason == null || reason.trim().isEmpty()) reason = status < 400 ? "OK" : "Error";
            return new WebResourceResponse(mime, enc, status, reason, out, body);
        } catch (Exception e) {
            return null;
        }
    }

    private static String header(Map<String, String> h, String name) {
        for (Map.Entry<String, String> e : h.entrySet()) if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        return null;
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    /* Troca endereços relativos de uma lista HLS por endereços completos. */
    static String absolutize(String text, String base) {
        URI b;
        try { b = new URI(base); } catch (Exception e) { return text; }
        StringBuilder sb = new StringBuilder();
        for (String line : text.split("\n", -1)) {
            String t = line.trim();
            if (t.isEmpty()) { sb.append(line).append('\n'); continue; }
            if (t.startsWith("#")) {
                int i = t.indexOf("URI=\"");
                if (i >= 0) {
                    int j = t.indexOf('"', i + 5);
                    if (j > i) {
                        String ref = t.substring(i + 5, j);
                        t = t.substring(0, i + 5) + resolve(b, ref) + t.substring(j);
                    }
                }
                sb.append(t).append('\n');
            } else {
                sb.append(resolve(b, t)).append('\n');
            }
        }
        return sb.toString();
    }

    static String resolve(URI base, String ref) {
        try {
            if (ref.matches("(?i)^[a-z][a-z0-9+.-]*:.*")) return ref;
            return base.resolve(ref).toString();
        } catch (Exception e) {
            return ref;
        }
    }

    /* ------------------------------------------------------------------
       Tela inteira: desde o Android 15 o app ocupa a tela toda; as barras do
       sistema ganham um espaço próprio para não cobrir o conteúdo.
       ------------------------------------------------------------------ */
    private void setupInsets() {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            @SuppressWarnings("deprecation")
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int l = 0, t = 0, r = 0, b = 0;
                if (!immersive) {
                    if (Build.VERSION.SDK_INT >= 30) {
                        Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                        l = i.left; t = i.top; r = i.right; b = i.bottom;
                    } else {
                        l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
                        r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
                    }
                }
                /* a barra de baixo do app vai até a borda da tela: a página recebe a altura
                   da barra de navegação do Android e coloca os ícones acima dela */
                v.setPadding(l, t, r, 0);
                float d = getResources().getDisplayMetrics().density;
                navInsetCss = d > 0 ? b / d : 0;
                pushInsets();
                return insets;
            }
        });
    }

    private void pushInsets() {
        if (web == null) return;
        web.evaluateJavascript("document.documentElement.style.setProperty('--sab','" + Math.round(navInsetCss) + "px')", null);
    }

    /* ------------------------------------------------------------------
       Botão Voltar (controle remoto e celular). A página decide: fecha a
       janela aberta, sai da tela cheia ou volta de tela; senão, fecha o app.
       ------------------------------------------------------------------ */
    private void setupBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedCallback cb = new OnBackInvokedCallback() {
                @Override
                public void onBackInvoked() {
                    handleBack();
                }
            };
            backCallback = cb;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb);
        }
    }

    private void handleBack() {
        web.evaluateJavascript("(window.maazarBack&&window.maazarBack())?'1':'0'", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (value == null || !value.contains("1")) finish();
            }
        });
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (pageReady) importFromIntent(intent);
        else pendingIntent = intent;
    }

    /** Abre uma lista .m3u recebida de outro app ("Abrir com Maazar Play"). */
    private void importFromIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData() == null) return;
        Uri uri = intent.getData();
        String scheme = uri.getScheme();
        try {
            if ("http".equals(scheme) || "https".equals(scheme)) {
                String js = "window.maazarImportUrl&&window.maazarImportUrl(" + JSONObject.quote(uri.toString()) + ")";
                web.evaluateJavascript(js, null);
                // usado pelo teste automático: depois de carregar a lista, toca o primeiro canal
                if (intent.getBooleanExtra("maazar_play_first", false)) {
                    web.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript("window.maazarPlayFirst&&window.maazarPlayFirst()", null);
                        }
                    }, 25000);
                }
                return;
            }
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) return;
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            String js = "window.maazarImport&&window.maazarImport(" + JSONObject.quote(fileName(uri)) + "," + JSONObject.quote(sb.toString()) + ")";
            web.evaluateJavascript(js, null);
        } catch (Exception e) {
            toast("Não consegui abrir esta lista.");
        }
    }

    private String fileName(Uri uri) {
        String name = "Lista importada";
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return name;
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** CH+/CH− e botões de mídia do controle remoto trocam de canal. */
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        if ((k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN) && cast != null && cast.connected()) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) cast.volume(k == KeyEvent.KEYCODE_VOLUME_UP);
            return true;
        }
        boolean up = k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP || k == KeyEvent.KEYCODE_MEDIA_NEXT;
        boolean down = k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN || k == KeyEvent.KEYCODE_MEDIA_PREVIOUS;
        if (up || down) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                web.evaluateJavascript("window.maazarKey&&window.maazarKey('" + (up ? "chup" : "chdown") + "')", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback((OnBackInvokedCallback) backCallback);
        }
        if (cast != null) cast.destroy();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private boolean isTelevision() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature("android.software.leanback")
                || !pm.hasSystemFeature("android.hardware.touchscreen");
    }

    @SuppressWarnings("deprecation")
    private void applyFullscreen(boolean on) {
        immersive = on;
        View decor = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController ctl = getWindow().getInsetsController();
            if (ctl != null) {
                if (on) {
                    ctl.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    ctl.hide(WindowInsets.Type.systemBars());
                } else {
                    ctl.show(WindowInsets.Type.systemBars());
                }
            }
        } else if (on) {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
        root.requestApplyInsets();
        if (!isTelevision()) {
            setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    private void jsProgress(final int pct, final String err) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) return;
                String e = err == null ? "null" : JSONObject.quote(err);
                web.evaluateJavascript("window.maazarUpdateProgress && window.maazarUpdateProgress(" + pct + "," + e + ")", null);
            }
        });
    }

    /* baixa o APK novo e abre a tela de instalação do Android */
    private void downloadAndInstall(String link) {
        HttpURLConnection c = null;
        try {
            String u = link;
            int hops = 0;
            while (true) {
                c = (HttpURLConnection) new URL(u).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                int code = c.getResponseCode();
                if ((code == 301 || code == 302 || code == 303 || code == 307 || code == 308) && hops++ < 6) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    u = new URL(new URL(u), loc).toString();
                    continue;
                }
                if (code != 200) throw new Exception("HTTP " + code);
                break;
            }
            long total = c.getContentLength();
            File dir = new File(getCacheDir(), "update");
            dir.mkdirs();
            File out = new File(dir, "Maazar-Play.apk");
            InputStream in = c.getInputStream();
            OutputStream os = new FileOutputStream(out);
            byte[] buf = new byte[65536];
            long got = 0;
            int n, last = -1;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                got += n;
                if (total > 0) {
                    int pct = (int) (got * 100 / total);
                    if (pct != last) { last = pct; jsProgress(pct, null); }
                }
            }
            os.close();
            in.close();
            jsProgress(100, null);
            final File apk = out;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    installApk(apk);
                }
            });
        } catch (Exception e) {
            jsProgress(-1, "Não foi possível baixar a atualização.");
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void installApk(File apk) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                toast("Permita instalar apps do Maazar Play e toque em Atualizar de novo.");
                Intent s = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                startActivity(s);
                return;
            }
            Uri uri = Build.VERSION.SDK_INT >= 24 ? FileProvider.getUriForFile(this, getPackageName() + ".update", apk) : Uri.fromFile(apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("Não foi possível abrir a instalação.");
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    /** Funções que a página chama através de window.AndroidBridge. */
    private class Bridge {
        @JavascriptInterface
        public void setFullscreen(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyFullscreen(on);
                }
            });
        }

        @JavascriptInterface
        public void openExternal(final String url) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(url), "video/*");
                    try {
                        startActivity(Intent.createChooser(i, "Abrir com"));
                    } catch (ActivityNotFoundException e) {
                        toast("Instale o VLC ou o MX Player para abrir este conteúdo.");
                    }
                }
            });
        }

        /* ---- transmitir para a TV (Chromecast / Google TV) ---- */
        @JavascriptInterface
        public boolean castSupported() {
            return cast != null && cast.supported();
        }

        @JavascriptInterface
        public void castStart(final String json) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (cast != null) cast.start(json);
                }
            });
        }

        /** sem Chromecast pelo app: abre o espelhamento de tela do Android */
        @JavascriptInterface
        public void openCastSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_CAST_SETTINGS));
                    } catch (Exception e) {
                        try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); }
                        catch (Exception e2) { toast("Use \"Transmitir tela\" no painel de atalhos do celular."); }
                    }
                }
            });
        }

        @JavascriptInterface
        public void castCmd(final String c, final double v) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (cast != null) cast.cmd(c, v);
                }
            });
        }

        @JavascriptInterface
        public boolean isTV() {
            return isTelevision();
        }

        /* ---- atualização da versão de instalação direta (fora das lojas) ---- */
        @JavascriptInterface
        public String appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean canSelfUpdate() {
            if (!BuildConfig.SELF_UPDATE) return false;
            String inst = null;
            try {
                if (Build.VERSION.SDK_INT >= 30) inst = getPackageManager().getInstallSourceInfo(getPackageName()).getInstallingPackageName();
                else inst = getPackageManager().getInstallerPackageName(getPackageName());
            } catch (Exception e) {
                inst = null;
            }
            /* instalado por uma loja: a loja cuida das atualizações */
            if (inst != null && (inst.equals("com.android.vending") || inst.equals("com.amazon.venezia") || inst.startsWith("com.amazon.") || inst.equals("com.google.android.feedback"))) return false;
            return true;
        }

        @JavascriptInterface
        public void updateApk(final String url) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    downloadAndInstall(url);
                }
            }).start();
        }

        @JavascriptInterface
        public String deviceName() {
            String m = (Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " " + (Build.MODEL == null ? "" : Build.MODEL);
            m = m.trim();
            if (m.isEmpty()) m = "Android";
            return (isTelevision() ? "TV " : "Celular ") + m;
        }
    }
}
