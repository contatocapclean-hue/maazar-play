package com.maazar.play;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaSeekOptions;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.images.WebImage;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * "Transmitir para a TV": envia o canal, filme ou episódio para um Chromecast / Google TV.
 * A TV busca o vídeo direto no servidor; se o servidor não deixar, o celular repassa (CastProxy).
 * A página recebe o estado por window.maazarCast({...}).
 */
class CastHelper {
    private final Activity act;
    private final WebView web;
    private CastContext ctx;
    private MediaRouter router;
    private MediaRouteSelector selector;

    private AlertDialog dialog;
    private ArrayAdapter<String> adapter;
    private TextView status;
    private final List<MediaRouter.RouteInfo> routes = new ArrayList<>();
    private boolean scanning = false;

    private JSONObject pending;      // o que a página pediu para transmitir
    private JSONArray cands;         // endereços a tentar, em ordem
    private int candIdx = 0;
    private int stage = 0;           // 0 = TV busca direto, 1 = pelo celular
    private long loadSeq = 0;
    private boolean trying = false;
    private long playingSince = 0;
    private boolean usingProxy = false;
    private String lastErr = null;
    private final StringBuilder trail = new StringBuilder();   // tentativas, para diagnóstico

    private CastProxy proxy;
    private RemoteMediaClient client;
    private WifiManager.WifiLock wifiLock;
    private PowerManager.WakeLock wakeLock;

    CastHelper(Activity a, WebView w) {
        act = a;
        web = w;
        try {
            ctx = CastContext.getSharedInstance(a);
            router = MediaRouter.getInstance(a);
            selector = ctx.getMergedSelector();
            if (selector == null) throw new IllegalStateException();
            ctx.getSessionManager().addSessionManagerListener(sessions, CastSession.class);
            CastSession s = ctx.getSessionManager().getCurrentCastSession();
            if (s != null && s.isConnected()) attach(s);
        } catch (Throwable t) {
            ctx = null;       // aparelho sem os serviços do Google (Fire TV, alguns TV Box)
        }
    }

    boolean supported() {
        return ctx != null;
    }

    boolean connected() {
        if (ctx == null) return false;
        CastSession s = ctx.getSessionManager().getCurrentCastSession();
        return s != null && s.isConnected();
    }

    /* ---------------- pedidos da página ---------------- */

    void start(String json) {
        if (ctx == null) { toast("Este aparelho não consegue transmitir."); return; }
        try { pending = new JSONObject(json); } catch (Exception e) { return; }
        if (connected()) { loadPending(); return; }
        showPicker();
    }

    void cmd(String c, double v) {
        if (ctx == null) return;
        if ("stop".equals(c)) {
            pending = null;
            ctx.getSessionManager().endCurrentSession(true);
            return;
        }
        if ("state".equals(c)) { pushState(); return; }
        RemoteMediaClient r = client;
        if (r == null) return;
        try {
            if ("play".equals(c)) r.play();
            else if ("pause".equals(c)) r.pause();
            else if ("seek".equals(c)) r.seek(new MediaSeekOptions.Builder().setPosition((long) Math.max(0, v)).build());
        } catch (Exception ignored) { }
    }

    /** Botões de volume do celular controlam o volume da TV durante a transmissão. */
    boolean volume(boolean up) {
        if (!connected()) return false;
        try {
            CastSession s = ctx.getSessionManager().getCurrentCastSession();
            double vol = Math.max(0, Math.min(1, s.getVolume() + (up ? 0.05 : -0.05)));
            s.setVolume(vol);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    void destroy() {
        stopScan();
        if (dialog != null) try { dialog.dismiss(); } catch (Exception ignored) { }
        releaseLocks();
        if (proxy != null) { proxy.close(); proxy = null; }
        if (ctx != null) try { ctx.getSessionManager().removeSessionManagerListener(sessions, CastSession.class); } catch (Exception ignored) { }
    }

    /* ---------------- escolha do aparelho ---------------- */

    private final MediaRouter.Callback routerCb = new MediaRouter.Callback() {
        @Override
        public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo info) { refreshRoutes(); }

        @Override
        public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo info) { refreshRoutes(); }

        @Override
        public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo info) { refreshRoutes(); }
    };

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, act.getResources().getDisplayMetrics());
    }

    private void showPicker() {
        if (dialog != null && dialog.isShowing()) return;
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        status = new TextView(act);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        status.setTextColor(0xFFB8C2EE);
        status.setPadding(0, 0, 0, dp(8));
        box.addView(status);
        ListView list = new ListView(act);
        adapter = new ArrayAdapter<>(act, android.R.layout.simple_list_item_1, new ArrayList<String>());
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos < 0 || pos >= routes.size()) return;
                MediaRouter.RouteInfo r = routes.get(pos);
                js("{\"on\":true,\"st\":\"connecting\",\"dev\":" + JSONObject.quote(r.getName()) + "}");
                dialog.dismiss();
                try { r.select(); } catch (Exception e) { js("{\"on\":false,\"err\":\"Não foi possível conectar a este aparelho.\"}"); }
            }
        });
        box.addView(list, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        dialog = new AlertDialog.Builder(act)
                .setTitle("Transmitir para a TV")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                stopScan();
            }
        });
        router.addCallback(selector, routerCb, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
        scanning = true;
        refreshRoutes();
        dialog.show();
    }

    private void stopScan() {
        if (scanning && router != null) {
            try { router.removeCallback(routerCb); } catch (Exception ignored) { }
        }
        scanning = false;
    }

    private void refreshRoutes() {
        if (router == null || adapter == null) return;
        routes.clear();
        List<String> names = new ArrayList<>();
        for (MediaRouter.RouteInfo r : router.getRoutes()) {
            if (r.isDefault() || !r.isEnabled() || !r.matchesSelector(selector)) continue;
            routes.add(r);
            String d = r.getDescription();
            names.add(d != null && d.length() > 0 && !d.equals(r.getName()) ? r.getName() + "  ·  " + d : r.getName());
        }
        adapter.clear();
        adapter.addAll(names);
        adapter.notifyDataSetChanged();
        if (status != null) status.setText(routes.isEmpty()
                ? "Procurando aparelhos...\nO celular e a TV (Chromecast ou Google TV) precisam estar no mesmo Wi-Fi."
                : "Escolha onde assistir:");
    }

    /* ---------------- sessão com a TV ---------------- */

    private final SessionManagerListener<CastSession> sessions = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(CastSession s) { }
        @Override public void onSessionStarted(CastSession s, String id) { attach(s); if (pending != null) loadPending(); else pushState(); }
        @Override public void onSessionStartFailed(CastSession s, int error) { js("{\"on\":false,\"err\":\"Não foi possível conectar à TV.\"}"); }
        @Override public void onSessionEnding(CastSession s) { }
        @Override public void onSessionEnded(CastSession s, int error) { detach(); js("{\"on\":false}"); }
        @Override public void onSessionResuming(CastSession s, String id) { }
        @Override public void onSessionResumed(CastSession s, boolean wasSuspended) { attach(s); if (pending != null) loadPending(); else pushState(); }
        @Override public void onSessionResumeFailed(CastSession s, int error) { }
        @Override public void onSessionSuspended(CastSession s, int reason) { }
    };

    private final RemoteMediaClient.Callback mediaCb = new RemoteMediaClient.Callback() {
        @Override
        public void onStatusUpdated() {
            onStatus();
        }
    };

    private final RemoteMediaClient.ProgressListener progress = new RemoteMediaClient.ProgressListener() {
        @Override
        public void onProgressUpdated(long pos, long dur) {
            pushState();
        }
    };

    private void attach(CastSession s) {
        RemoteMediaClient r = s.getRemoteMediaClient();
        if (r == client) return;
        detachClient();
        client = r;
        if (client != null) {
            client.registerCallback(mediaCb);
            client.addProgressListener(progress, 1000);
        }
    }

    private void detachClient() {
        if (client != null) {
            try { client.unregisterCallback(mediaCb); client.removeProgressListener(progress); } catch (Exception ignored) { }
        }
        client = null;
    }

    private void detach() {
        detachClient();
        trying = false;
        pending = null;
        usingProxy = false;
        releaseLocks();
    }

    /* ---------------- envio do vídeo, com alternativas ---------------- */

    private void loadPending() {
        if (pending == null) return;
        cands = pending.optJSONArray("urls");
        candIdx = 0;
        stage = 0;
        lastErr = null;
        trail.setLength(0);
        trying = true;
        attempt();
    }

    private void attempt() {
        if (pending == null) return;
        if (client == null) {
            CastSession s = ctx.getSessionManager().getCurrentCastSession();
            if (s != null) attach(s);
        }
        if (client == null || cands == null || candIdx >= cands.length()) {
            trying = false;
            js("{\"on\":true,\"st\":\"error\",\"dev\":" + JSONObject.quote(deviceName()) + ",\"err\":"
                    + JSONObject.quote((lastErr != null ? lastErr : "A TV não conseguiu abrir este conteúdo. Tente outro canal ou volte a assistir no celular.")
                    + (trail.length() > 0 ? " (detalhe: " + trail.toString().trim() + ")" : "")) + "}");
            return;
        }
        JSONObject c = cands.optJSONObject(candIdx);
        String url = c == null ? "" : c.optString("u", "");
        String type = c == null ? "video/mp4" : c.optString("t", "video/mp4");
        if (url.isEmpty()) { next(); return; }
        String send = url;
        if (stage == 1) {
            if (proxy == null) proxy = CastProxy.open();
            if (proxy == null) { lastErr = "Conecte o celular ao mesmo Wi-Fi da TV."; note("sem-wifi"); next(); return; }
            send = proxy.wrap(url);
        }
        final boolean viaProxy = stage == 1;
        boolean live = pending.optBoolean("live", false);
        MediaMetadata md = new MediaMetadata(live ? MediaMetadata.MEDIA_TYPE_GENERIC : MediaMetadata.MEDIA_TYPE_MOVIE);
        md.putString(MediaMetadata.KEY_TITLE, pending.optString("title", "Maazar Play"));
        String sub = pending.optString("sub", "");
        if (!sub.isEmpty()) md.putString(MediaMetadata.KEY_SUBTITLE, sub);
        String poster = pending.optString("poster", "");
        if (poster.startsWith("http")) md.addImage(new WebImage(Uri.parse(poster)));

        MediaInfo.Builder b = new MediaInfo.Builder(send)
                .setStreamType(live ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(type)
                .setMetadata(md);
        MediaLoadRequestData req = new MediaLoadRequestData.Builder()
                .setMediaInfo(b.build())
                .setAutoplay(true)
                .setCurrentTime(live ? 0 : Math.max(0, pending.optLong("pos", 0)))
                .build();

        final long seq = ++loadSeq;
        playingSince = 0;
        js("{\"on\":true,\"st\":\"loading\",\"dev\":" + JSONObject.quote(deviceName()) + "}");
        try {
            PendingResult<RemoteMediaClient.MediaChannelResult> pr = client.load(req);
            pr.setResultCallback(new ResultCallback<RemoteMediaClient.MediaChannelResult>() {
                @Override
                public void onResult(RemoteMediaClient.MediaChannelResult r) {
                    if (seq != loadSeq) return;
                    if (r.getStatus().isSuccess()) {
                        usingProxy = viaProxy;
                        if (viaProxy) holdLocks(); else releaseLocks();
                        playingSince = SystemClock.elapsedRealtime();
                        pushState();
                    } else {
                        note(String.valueOf(r.getStatus().getStatusCode()));
                        next();
                    }
                }
            }, 25, TimeUnit.SECONDS);
        } catch (Exception e) {
            note("x");
            next();
        }
    }

    /** anota a tentativa que falhou: nº do endereço, d = TV direto / c = pelo celular, e o código */
    private void note(String code) {
        String t = "?";
        try { t = cands.optJSONObject(candIdx).optString("t", "?").replace("application/x-mpegurl", "hls").replace("video/", ""); } catch (Exception ignored) { }
        trail.append(candIdx + 1).append(stage == 0 ? "d" : "c").append('-').append(t).append(':').append(code).append(' ');
    }

    private void next() {
        if (stage == 0) stage = 1;
        else { stage = 0; candIdx++; }
        attempt();
    }

    private void onStatus() {
        RemoteMediaClient r = client;
        if (r == null) return;
        int ps = r.getPlayerState();
        if (ps == MediaStatus.PLAYER_STATE_IDLE && r.getIdleReason() == MediaStatus.IDLE_REASON_ERROR) {
            // começou e logo falhou (ex.: a TV abriu a lista mas não os pedaços do vídeo): tenta a próxima forma
            if (trying && pending != null) {
                if (playingSince == 0) return;   // a resposta do pedido de abertura decide
                if (SystemClock.elapsedRealtime() - playingSince < 20000) {
                    note("idle-err");
                    loadSeq++;
                    next();
                    return;
                }
            }
            js("{\"on\":true,\"st\":\"error\",\"dev\":" + JSONObject.quote(deviceName()) + ",\"err\":\"A transmissão parou. Tente de novo.\"}");
            return;
        }
        if (ps == MediaStatus.PLAYER_STATE_PLAYING && playingSince > 0 && SystemClock.elapsedRealtime() - playingSince > 20000) trying = false;
        pushState();
    }

    private String deviceName() {
        try {
            CastSession s = ctx.getSessionManager().getCurrentCastSession();
            CastDevice d = s == null ? null : s.getCastDevice();
            if (d != null && d.getFriendlyName() != null) return d.getFriendlyName();
        } catch (Exception ignored) { }
        return "TV";
    }

    private void pushState() {
        if (!connected()) return;
        RemoteMediaClient r = client;
        String st = "idle";
        long pos = 0, dur = 0;
        boolean has = false;
        if (r != null && r.getMediaInfo() != null) {
            has = true;
            int ps = r.getPlayerState();
            if (ps == MediaStatus.PLAYER_STATE_PLAYING) st = "playing";
            else if (ps == MediaStatus.PLAYER_STATE_PAUSED) st = "paused";
            else if (ps == MediaStatus.PLAYER_STATE_BUFFERING || ps == 5 /* carregando */) st = "buffering";
            else if (ps == MediaStatus.PLAYER_STATE_IDLE && r.getIdleReason() == MediaStatus.IDLE_REASON_FINISHED) st = "ended";
            pos = r.getApproximateStreamPosition();
            dur = r.getStreamDuration();
        }
        if (!has && trying) return;
        if (!has) st = "ready";
        js("{\"on\":true,\"st\":\"" + st + "\",\"dev\":" + JSONObject.quote(deviceName()) + ",\"pos\":" + pos + ",\"dur\":" + dur
                + ",\"proxy\":" + usingProxy + "}");
    }

    /* ---------------- energia: com o celular repassando o vídeo, o Wi-Fi não pode dormir ---------------- */

    @SuppressWarnings("deprecation")
    private void holdLocks() {
        try {
            if (wifiLock == null) {
                WifiManager wm = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "maazar:cast");
                    wifiLock.setReferenceCounted(false);
                }
            }
            if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
            if (wakeLock == null) {
                PowerManager pm = (PowerManager) act.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "maazar:cast");
                    wakeLock.setReferenceCounted(false);
                }
            }
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(4 * 60 * 60 * 1000L);
        } catch (Exception ignored) { }
    }

    private void releaseLocks() {
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { }
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) { }
    }

    /* ---------------- ---------------- */

    private void js(final String json) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript("window.maazarCast&&window.maazarCast(" + json + ")", null);
            }
        });
    }

    private void toast(String m) {
        Toast.makeText(act, m, Toast.LENGTH_LONG).show();
    }
}
