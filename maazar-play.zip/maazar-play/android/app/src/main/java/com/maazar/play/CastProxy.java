package com.maazar.play;

import android.util.Base64;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ponte local para a transmissão: a TV (Chromecast) pede o vídeo ao celular, que busca no servidor
 * da lista e repassa. Serve para servidores que não liberam o acesso direto da TV (CORS).
 * Só atende endereços com uma chave aleatória criada a cada abertura do app.
 */
class CastProxy {
    private final ServerSocket server;
    private final String host;
    private final String token;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running = true;

    private CastProxy(ServerSocket s, String host) {
        this.server = s;
        this.host = host;
        byte[] r = new byte[12];
        new SecureRandom().nextBytes(r);
        this.token = Base64.encodeToString(r, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop();
            }
        }, "cast-proxy");
        t.setDaemon(true);
        t.start();
    }

    /** Abre a ponte no Wi-Fi do celular. Devolve null se o celular não estiver numa rede local. */
    static CastProxy open() {
        try {
            String ip = localIp();
            if (ip == null) return null;
            ServerSocket s = new ServerSocket(0, 50, InetAddress.getByName("0.0.0.0"));
            return new CastProxy(s, ip);
        } catch (Exception e) {
            return null;
        }
    }

    void close() {
        running = false;
        try { server.close(); } catch (Exception ignored) { }
        pool.shutdownNow();
    }

    /** Endereço que a TV usa para pedir este vídeo através do celular. */
    String wrap(String url) {
        String b = Base64.encodeToString(url.getBytes(StandardCharsets.UTF_8), Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        String name = "v";
        try {
            String p = new URI(url).getPath();
            if (p != null) {
                int i = p.lastIndexOf('/');
                String last = i >= 0 ? p.substring(i + 1) : p;
                last = last.replaceAll("[^A-Za-z0-9._-]", "");
                if (!last.isEmpty()) name = last;
            }
        } catch (Exception ignored) { }
        return "http://" + host + ":" + server.getLocalPort() + "/" + token + "/" + b + "/" + name;
    }

    private static String localIp() throws Exception {
        String other = null;
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            String n = ni.getName() == null ? "" : ni.getName().toLowerCase(Locale.ROOT);
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                if (n.startsWith("wlan") || n.startsWith("eth") || n.startsWith("ap") || n.startsWith("swlan")) return a.getHostAddress();
                if (other == null && !n.startsWith("rmnet") && !n.startsWith("ccmni")) other = a.getHostAddress();
            }
        }
        return other;
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket s = server.accept();
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        handle(s);
                    }
                });
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    private static String readLine(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 16384) break;
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private static final String CORS = "Access-Control-Allow-Origin: *\r\n"
            + "Access-Control-Allow-Headers: *\r\n"
            + "Access-Control-Allow-Methods: GET, HEAD, OPTIONS\r\n"
            + "Access-Control-Expose-Headers: *\r\n";

    private void handle(Socket s) {
        HttpURLConnection c = null;
        try {
            s.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 65536);
            String first = readLine(in);
            if (first == null) return;
            String[] parts = first.split(" ");
            if (parts.length < 2) return;
            String method = parts[0].toUpperCase(Locale.ROOT);
            Map<String, String> h = new HashMap<>();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int i = line.indexOf(':');
                if (i > 0) h.put(line.substring(0, i).trim().toLowerCase(Locale.ROOT), line.substring(i + 1).trim());
            }
            if (method.equals("OPTIONS")) {
                out.write(("HTTP/1.1 204 No Content\r\n" + CORS + "Content-Length: 0\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                out.flush();
                return;
            }
            String path = parts[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            String[] seg = path.split("/");
            if (seg.length < 3 || !token.equals(seg[1]) || !(method.equals("GET") || method.equals("HEAD"))) {
                out.write(("HTTP/1.1 404 Not Found\r\n" + CORS + "Content-Length: 0\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));
                out.flush();
                return;
            }
            String target = new String(Base64.decode(seg[2], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8);

            String current = target;
            int status = 0;
            for (int hop = 0; hop < 6; hop++) {
                c = (HttpURLConnection) new URL(current).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestMethod(method);
                String ua = h.get("user-agent");
                c.setRequestProperty("User-Agent", ua != null ? ua : "Mozilla/5.0 (Linux; Android) MaazarPlay");
                if (h.get("range") != null) c.setRequestProperty("Range", h.get("range"));
                status = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                if (status >= 300 && status < 400 && loc != null) {
                    current = new URL(new URL(current), loc).toString();
                    c.disconnect();
                    c = null;
                    continue;
                }
                break;
            }
            if (c == null) throw new Exception("redirects");

            String ctype = c.getContentType();
            String lc = current.toLowerCase(Locale.ROOT);
            boolean playlist = (ctype != null && ctype.toLowerCase(Locale.ROOT).contains("mpegurl")) || lc.contains(".m3u8");
            InputStream body = status >= 400 ? c.getErrorStream() : c.getInputStream();
            String reason = c.getResponseMessage();
            if (reason == null || reason.trim().isEmpty()) reason = status < 400 ? "OK" : "Error";
            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n").append(CORS).append("Connection: close\r\n");

            if (playlist && status < 400 && method.equals("GET") && body != null) {
                String text = rewrite(readAll(body), current);
                byte[] b = text.getBytes(StandardCharsets.UTF_8);
                head.append("Content-Type: application/vnd.apple.mpegurl\r\n").append("Cache-Control: no-cache\r\n").append("Content-Length: ").append(b.length).append("\r\n\r\n");
                out.write(head.toString().getBytes(StandardCharsets.UTF_8));
                out.write(b);
                out.flush();
                return;
            }
            if (ctype != null) head.append("Content-Type: ").append(ctype).append("\r\n");
            String len = c.getHeaderField("Content-Length");
            if (len != null) head.append("Content-Length: ").append(len).append("\r\n");
            String cr = c.getHeaderField("Content-Range");
            if (cr != null) head.append("Content-Range: ").append(cr).append("\r\n");
            String ar = c.getHeaderField("Accept-Ranges");
            if (ar != null) head.append("Accept-Ranges: ").append(ar).append("\r\n");
            head.append("\r\n");
            out.write(head.toString().getBytes(StandardCharsets.UTF_8));
            if (method.equals("GET") && body != null) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = body.read(buf)) > 0) out.write(buf, 0, n);
            }
            out.flush();
        } catch (Exception ignored) {
        } finally {
            if (c != null) try { c.disconnect(); } catch (Exception ignored) { }
            try { s.close(); } catch (Exception ignored) { }
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    /** Lista HLS: cada endereço passa também pela ponte. */
    private String rewrite(String text, String base) {
        URI b;
        try { b = new URI(base); } catch (Exception e) { return text; }
        StringBuilder sb = new StringBuilder();
        for (String line : text.split("\n", -1)) {
            String t = line.trim();
            if (t.isEmpty()) { sb.append('\n'); continue; }
            if (t.startsWith("#")) {
                int i = t.indexOf("URI=\"");
                if (i >= 0) {
                    int j = t.indexOf('"', i + 5);
                    if (j > i) t = t.substring(0, i + 5) + wrap(MainActivity.resolve(b, t.substring(i + 5, j))) + t.substring(j);
                }
                sb.append(t).append('\n');
            } else {
                sb.append(wrap(MainActivity.resolve(b, t))).append('\n');
            }
        }
        return sb.toString();
    }
}
